$(document).ready(function() {
    // Initialize elements
    const chatMessages = $('#chat-messages');
    const userInput = $('#user-input');
    const sendBtn = $('#send-btn');
    const voiceBtn = $('#voice-btn');
    const fileUpload = $('#file-upload');
    const locationInput = $('#location-input');
    const recordingIndicator = $('#recording-indicator');
    const stopRecordingBtn = $('#stop-recording');
    const clearChatBtn = $('#clear-chat');
    const weatherInfo = $('#weather-info');
    
    let mediaRecorder;
    let audioChunks = [];
    let isRecording = false;
    
    // Initialize particles.js background
    particlesJS('particles-js', {
        particles: {
            number: { value: 80, density: { enable: true, value_area: 800 } },
            color: { value: "#00e676" },
            shape: { type: "circle" },
            opacity: { value: 0.5, random: true },
            size: { value: 3, random: true },
            line_linked: { enable: true, distance: 150, color: "#00e676", opacity: 0.2, width: 1 },
            move: { enable: true, speed: 2, direction: "none", random: true, straight: false, out_mode: "out" }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: { enable: true, mode: "grab" },
                onclick: { enable: true, mode: "push" }
            }
        }
    });

    // Load previous conversation
    loadConversation();
    
    // Event listeners with animation effects
    sendBtn.click(sendMessage).hover(buttonHoverIn, buttonHoverOut);
    voiceBtn.mousedown(startRecording).mouseup(stopRecording).mouseleave(stopRecording).hover(buttonHoverIn, buttonHoverOut);
    clearChatBtn.click(clearConversation).hover(buttonHoverIn, buttonHoverOut);
    stopRecordingBtn.click(stopRecording).hover(buttonHoverIn, buttonHoverOut);
    
    userInput.keypress(function(e) {
        if (e.which === 13) sendMessage();
    }).focus(inputFocus).blur(inputBlur);
    
    fileUpload.change(handleFileUpload);
    
    // Button hover effects
    function buttonHoverIn() {
        $(this).css({
            'transform': 'translateY(-3px) scale(1.05)',
            'box-shadow': '0 5px 15px rgba(0, 230, 118, 0.4)'
        });
    }
    
    function buttonHoverOut() {
        $(this).css({
            'transform': 'translateY(0) scale(1)',
            'box-shadow': 'none'
        });
    }
    
    // Input focus effects
    function inputFocus() {
        $(this).css({
            'border-color': '#00e676',
            'box-shadow': '0 0 0 2px rgba(0, 230, 118, 0.2)'
        });
    }
    
    function inputBlur() {
        $(this).css({
            'border-color': '#ddd',
            'box-shadow': 'none'
        });
    }
    
    // Enhanced send message function
    function sendMessage() {
        const message = userInput.val().trim();
        const location = locationInput.val().trim();
        
        if (message || $('.file-preview').length) {
            // Add pulse animation to send button
            sendBtn.addClass('pulse');
            setTimeout(() => sendBtn.removeClass('pulse'), 300);
            
            // Display user message with animation
            addMessage('user', message, 'text');
            
            // Get file data if exists
            let fileData = null;
            const filePreview = $('.file-preview');
            if (filePreview.length) {
                fileData = filePreview.data('file');
                filePreview.remove();
            }
            
            // Show typing indicator
            showTypingIndicator();
            
            // Send to server
            const formData = new FormData();
            formData.append('message', message);
            formData.append('location', location);
            
            if (fileData) {
                formData.append('file', fileData);
            }
            
            $.ajax({
                url: '/api/chat',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    hideTypingIndicator();
                    
                    // Display assistant response with animation
                    const msg = addMessage('assistant', response.response, 'text');
                    
                    // Add voice playback if available
                    if (response.voice_url) {
                        addAudioPlayer(msg.id, response.voice_url);
                    }
                    
                    // Add diagram if available
                    if (response.diagram) {
                        addDiagram(msg.id, response.diagram);
                    }
                    
                    // Show weather info if available
                    if (response.weather) {
                        showWeatherInfo(response.weather);
                    }
                    
                    // Scroll to bottom with smooth animation
                    smoothScrollToBottom();
                },
                error: function(xhr, status, error) {
                    hideTypingIndicator();
                    addMessage('assistant', 'Sorry, an error occurred. Please try again.', 'text');
                    console.error(error);
                }
            });
            
            // Clear input with animation
            userInput.val('').animate({ opacity: 0.5 }, 100).animate({ opacity: 1 }, 100);
            locationInput.val('');
        } else {
            // Shake animation for empty input
            userInput.addClass('shake');
            setTimeout(() => userInput.removeClass('shake'), 500);
        }
    }
    
    // Enhanced message display with animations
    function addMessage(role, content, type, id = null) {
        if (!content && type !== 'audio') return;
        
        const messageId = id || Date.now();
        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        let messageHtml = `
            <div class="message ${role}-message" id="msg-${messageId}">
                <div class="message-content">
                    ${type === 'text' ? content : ''}
                    ${type === 'image' ? `
                        <div class="image-preview-container">
                            <img src="${content}" alt="Uploaded image" class="preview-image">
                            <div class="image-overlay">
                                <i class="fas fa-expand"></i>
                            </div>
                        </div>
                        <p class="image-caption">Image analysis requested</p>
                    ` : ''}
                    ${type === 'document' ? `
                        <div class="document-preview">
                            <i class="fas fa-file-alt"></i>
                            <span>${content}</span>
                        </div>
                    ` : ''}
                    ${type === 'audio' ? `<p class="audio-message-tag"><i class="fas fa-microphone"></i> Voice message</p>` : ''}
                    ${type === 'weather' ? `<p class="weather-message-tag"><i class="fas fa-cloud-sun"></i> ${content}</p>` : ''}
                </div>
                <div class="message-meta">
                    <span class="timestamp">${timestamp}</span>
                    ${role === 'assistant' ? '<span class="assistant-badge">AgriBot</span>' : '<span class="user-badge">You</span>'}
                </div>
            </div>
        `;
        
        chatMessages.append(messageHtml);
        
        // Animate message appearance
        $(`#msg-${messageId}`).hide().fadeIn(300);
        
        // Smooth scroll to bottom
        smoothScrollToBottom();
        
        return { id: messageId };
    }
    
    // Enhanced audio player with visualizer
    function addAudioPlayer(messageId, audioUrl) {
        const audioHtml = `
            <div class="audio-player-container">
                <audio controls class="audio-element">
                    <source src="${audioUrl}" type="audio/mpeg">
                </audio>
                <canvas class="audio-visualizer"></canvas>
            </div>
        `;
        
        $(`#msg-${messageId} .message-content`).append(audioHtml);
        
        // Initialize audio visualizer
        initAudioVisualizer(`#msg-${messageId} .audio-element`, `#msg-${messageId} .audio-visualizer`);
    }
    
    // Audio visualizer function
    function initAudioVisualizer(audioSelector, canvasSelector) {
        const audio = $(audioSelector)[0];
        const canvas = $(canvasSelector)[0];
        const ctx = canvas.getContext('2d');
        
        canvas.width = 250;
        canvas.height = 50;
        
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const analyser = audioContext.createAnalyser();
        const source = audioContext.createMediaElementSource(audio);
        
        source.connect(analyser);
        analyser.connect(audioContext.destination);
        analyser.fftSize = 64;
        
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        
        function draw() {
            requestAnimationFrame(draw);
            analyser.getByteFrequencyData(dataArray);
            
            ctx.fillStyle = 'rgba(0, 0, 0, 0)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            const barWidth = (canvas.width / bufferLength) * 2.5;
            let x = 0;
            
            for (let i = 0; i < bufferLength; i++) {
                const barHeight = dataArray[i] / 2;
                ctx.fillStyle = `rgb(${barHeight + 100}, 230, ${barHeight + 118})`;
                ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
                x += barWidth + 1;
            }
        }
        
        draw();
    }
    
    // Enhanced diagram display
    function addDiagram(messageId, diagramData) {
        const diagramHtml = `
            <div class="diagram-container">
                <img src="data:image/png;base64,${diagramData}" alt="Agricultural Diagram" class="diagram-image">
                <div class="diagram-toolbar">
                    <button class="diagram-btn zoom-in"><i class="fas fa-search-plus"></i></button>
                    <button class="diagram-btn zoom-out"><i class="fas fa-search-minus"></i></button>
                    <button class="diagram-btn download-diagram"><i class="fas fa-download"></i></button>
                </div>
            </div>
        `;
        
        $(`#msg-${messageId} .message-content`).append(diagramHtml);
        
        // Add diagram controls
        $(`#msg-${messageId} .zoom-in`).click(function() {
            const img = $(this).closest('.diagram-container').find('.diagram-image');
            const currentScale = parseFloat(img.css('transform').split(',')[3]) || 1;
            img.css('transform', `scale(${currentScale + 0.1})`);
        });
        
        $(`#msg-${messageId} .zoom-out`).click(function() {
            const img = $(this).closest('.diagram-container').find('.diagram-image');
            const currentScale = parseFloat(img.css('transform').split(',')[3]) || 1;
            if (currentScale > 0.5) {
                img.css('transform', `scale(${currentScale - 0.1})`);
            }
        });
        
        $(`#msg-${messageId} .download-diagram`).click(function() {
            const imgSrc = $(this).closest('.diagram-container').find('.diagram-image').attr('src');
            const link = document.createElement('a');
            link.href = imgSrc;
            link.download = 'agricultural-diagram.png';
            link.click();
        });
    }
    
    // Enhanced weather display
    function showWeatherInfo(weather) {
        weatherInfo.html(`
            <div class="weather-card animated fadeIn">
                <div class="weather-icon">
                    <img src="https://openweathermap.org/img/wn/${weather.icon}@2x.png" alt="${weather.conditions}">
                </div>
                <div class="weather-details">
                    <div class="weather-temp">${weather.temp}°C</div>
                    <div class="weather-desc">${weather.conditions}</div>
                    <div class="weather-extras">
                        <span><i class="fas fa-tint"></i> ${weather.humidity}%</span>
                        <span><i class="fas fa-wind"></i> ${weather.wind_speed} m/s</span>
                    </div>
                </div>
            </div>
        `).hide().fadeIn(300);
    }
    
    // Enhanced voice recording
    function startRecording() {
        if (isRecording) return;
        
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then(stream => {
                    isRecording = true;
                    mediaRecorder = new MediaRecorder(stream);
                    audioChunks = [];
                    
                    mediaRecorder.ondataavailable = function(e) {
                        audioChunks.push(e.data);
                    };
                    
                    mediaRecorder.onstop = function() {
                        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                        const audioUrl = URL.createObjectURL(audioBlob);
                        
                        // Create a file from the blob
                        const audioFile = new File([audioBlob], 'recording.wav', { type: 'audio/wav' });
                        
                        // Show enhanced preview
                        const previewHtml = `
                            <div class="file-preview voice-preview" data-file="${audioFile}">
                                <div class="voice-waveform" id="voice-waveform"></div>
                                <div class="voice-controls">
                                    <audio controls>
                                        <source src="${audioUrl}" type="audio/wav">
                                    </audio>
                                    <button class="btn btn-small send-voice">
                                        <i class="fas fa-paper-plane"></i> Send
                                    </button>
                                </div>
                            </div>
                        `;
                        
                        $('.input-area').prepend(previewHtml);
                        
                        // Initialize waveform visualization
                        initWaveform(audioUrl, '#voice-waveform');
                        
                        // Add send button handler
                        $('.send-voice').click(function() {
                            sendMessage();
                        });
                    };
                    
                    mediaRecorder.start();
                    recordingIndicator.show();
                    voiceBtn.addClass('recording-active');
                    
                    // Start recording animation
                    const recordingDot = $('<div class="recording-dot"></div>');
                    voiceBtn.append(recordingDot);
                })
                .catch(error => {
                    console.error('Error accessing microphone:', error);
                    addMessage('assistant', 'Microphone access denied. Please allow microphone access to use voice recording.', 'text');
                });
        } else {
            addMessage('assistant', 'Your browser does not support voice recording.', 'text');
        }
    }
    
    function stopRecording() {
        if (isRecording && mediaRecorder) {
            mediaRecorder.stop();
            isRecording = false;
            recordingIndicator.hide();
            voiceBtn.removeClass('recording-active');
            voiceBtn.find('.recording-dot').remove();
            
            // Stop all tracks
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
    }
    
    // Enhanced file upload handling
    function handleFileUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        // Remove any existing preview
        $('.file-preview').remove();
        
        const reader = new FileReader();
        reader.onload = function(e) {
            let previewHtml = '';
            
            if (file.type.startsWith('image/')) {
                previewHtml = `
                    <div class="file-preview image-preview" data-file="${file}">
                        <div class="preview-container">
                            <img src="${e.target.result}" alt="Preview" class="preview-image">
                            <div class="preview-overlay">
                                <i class="fas fa-search-plus"></i>
                            </div>
                        </div>
                        <div class="file-info">
                            <span class="file-name">${file.name}</span>
                            <span class="file-size">${formatFileSize(file.size)}</span>
                        </div>
                    </div>
                `;
            } else if (file.type === 'application/pdf' || file.name.endsWith('.txt')) {
                previewHtml = `
                    <div class="file-preview document-preview" data-file="${file}">
                        <div class="document-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="file-info">
                            <span class="file-name">${file.name}</span>
                            <span class="file-size">${formatFileSize(file.size)}</span>
                            <span class="file-type">${file.type.split('/')[1] || file.name.split('.').pop()} file</span>
                        </div>
                    </div>
                `;
            } else {
                addMessage('assistant', 'Unsupported file type. Please upload an image, PDF, or text file.', 'text');
                return;
            }
            
            $('.input-area').prepend(previewHtml);
            
            // Add image zoom effect
            if (file.type.startsWith('image/')) {
                $('.preview-image').click(function() {
                    const imgSrc = $(this).attr('src');
                    showImageModal(imgSrc);
                });
            }
        };
        
        if (file.type.startsWith('image/')) {
            reader.readAsDataURL(file);
        } else {
            reader.onload({ target: { result: '' } });
        }
        
        fileUpload.val('');
    }
    
    // Show image in modal
    function showImageModal(src) {
        const modalHtml = `
            <div class="image-modal">
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    <img src="${src}" alt="Full size preview">
                </div>
            </div>
        `;
        
        $('body').append(modalHtml);
        
        $('.close-modal').click(function() {
            $('.image-modal').remove();
        });
        
        $(document).keyup(function(e) {
            if (e.key === "Escape") {
                $('.image-modal').remove();
            }
        });
    }
    
    // Format file size
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }
    
    // Typing indicator functions
    function showTypingIndicator() {
        const typingHtml = `
            <div class="message assistant-message" id="typing-indicator">
                <div class="message-content typing">
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                    <span class="typing-text">AgriBot is thinking...</span>
                </div>
            </div>
        `;
        chatMessages.append(typingHtml);
        smoothScrollToBottom();
    }
    
    function hideTypingIndicator() {
        $('#typing-indicator').fadeOut(200, function() {
            $(this).remove();
        });
    }
    
    // Load conversation history
    function loadConversation() {
        $.get('/api/conversation', function(conversation) {
            conversation.forEach(msg => {
                const message = addMessage(msg.role, msg.content, msg.type, Date.now());
                
                if (msg.voice_url) {
                    addAudioPlayer(message.id, msg.voice_url);
                }
                
                if (msg.diagram) {
                    addDiagram(message.id, msg.diagram);
                }
            });
            
            smoothScrollToBottom();
        });
    }
    
    // Clear conversation with confirmation
    function clearConversation() {
        // Show confirmation dialog with animation
        const confirmation = $(`
            <div class="confirmation-dialog">
                <div class="confirmation-content">
                    <p>Are you sure you want to clear the conversation?</p>
                    <div class="confirmation-buttons">
                        <button class="btn confirm-clear">Yes, clear</button>
                        <button class="btn cancel-clear">Cancel</button>
                    </div>
                </div>
            </div>
        `);
        
        $('body').append(confirmation);
        
        $('.confirm-clear').click(function() {
            $.post('/api/clear', function() {
                chatMessages.empty();
                weatherInfo.hide();
                confirmation.fadeOut(200, function() {
                    $(this).remove();
                });
                addMessage('assistant', 'Conversation cleared. How can I help you with your agricultural questions?', 'text');
            });
        });
        
        $('.cancel-clear').click(function() {
            confirmation.fadeOut(200, function() {
                $(this).remove();
            });
        });
    }
    
    // Smooth scroll to bottom
    function smoothScrollToBottom() {
        chatMessages.stop().animate({ scrollTop: chatMessages[0].scrollHeight }, 500);
    }
    
    // Initialize waveform visualization for audio
    function initWaveform(audioUrl, canvasSelector) {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const analyser = audioContext.createAnalyser();
        const canvas = $(canvasSelector)[0];
        const ctx = canvas.getContext('2d');
        
        canvas.width = 300;
        canvas.height = 60;
        
        fetch(audioUrl)
            .then(response => response.arrayBuffer())
            .then(arrayBuffer => audioContext.decodeAudioData(arrayBuffer))
            .then(audioBuffer => {
                const source = audioContext.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(analyser);
                analyser.connect(audioContext.destination);
                analyser.fftSize = 256;
                
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);
                
                function drawWaveform() {
                    requestAnimationFrame(drawWaveform);
                    analyser.getByteTimeDomainData(dataArray);
                    
                    ctx.fillStyle = 'rgba(0, 0, 0, 0)';
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                    
                    ctx.lineWidth = 2;
                    ctx.strokeStyle = '#00e676';
                    ctx.beginPath();
                    
                    const sliceWidth = canvas.width * 1.0 / bufferLength;
                    let x = 0;
                    
                    for (let i = 0; i < bufferLength; i++) {
                        const v = dataArray[i] / 128.0;
                        const y = v * canvas.height / 2;
                        
                        if (i === 0) {
                            ctx.moveTo(x, y);
                        } else {
                            ctx.lineTo(x, y);
                        }
                        
                        x += sliceWidth;
                    }
                    
                    ctx.lineTo(canvas.width, canvas.height / 2);
                    ctx.stroke();
                }
                
                drawWaveform();
            });
    }
});