import os
import speech_recognition as sr
import pyttsx3
from pydub import AudioSegment
from config import Config

class AudioUtils:
    @staticmethod
    def text_to_speech(text, filename='response.mp3'):
        try:
            engine = pyttsx3.init()
            engine.save_to_file(text, os.path.join(Config.UPLOAD_FOLDER, filename))
            engine.runAndWait()
            return filename
        except Exception as e:
            print(f"Error in text-to-speech: {e}")
            return None
    
    @staticmethod
    def speech_to_text(audio_file):
        try:
            # Convert to WAV if needed
            if not audio_file.lower().endswith('.wav'):
                audio = AudioSegment.from_file(audio_file)
                wav_file = os.path.splitext(audio_file)[0] + '.wav'
                audio.export(wav_file, format='wav')
                audio_file = wav_file
            
            recognizer = sr.Recognizer()
            with sr.AudioFile(audio_file) as source:
                audio_data = recognizer.record(source)
                text = recognizer.recognize_google(audio_data)
                return text
        except Exception as e:
            print(f"Error in speech-to-text: {e}")
            return None