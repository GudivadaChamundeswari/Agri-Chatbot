import os
from groq import Groq
from config import Config

class GroqClient:
    def __init__(self):
        self.client = Groq(api_key=Config.GROQ_API_KEY)
    
    def get_response(self, messages, model="llama3-70b-8192", temperature=0.5):
        try:
            chat_completion = self.client.chat.completions.create(
                messages=messages,
                model=model,
                temperature=temperature
            )
            return chat_completion.choices[0].message.content
        except Exception as e:
            return f"Error getting response from Groq API: {str(e)}"
    
    def generate_image_description(self, image_path):
        # This would use vision capabilities when available
        # For now, we'll simulate it
        prompt = f"""
        Analyze this agricultural image and provide detailed insights:
        - Identify crops, plants, or animals visible
        - Note any signs of disease, pests, or nutrient deficiencies
        - Estimate growth stage if applicable
        - Provide recommendations if issues are detected
        """
        return self.get_response([{"role": "user", "content": prompt}])
    
    def analyze_document(self, text):
        prompt = f"""
        Analyze this agricultural document and provide a summary with key points:
        {text}
        """
        return self.get_response([{"role": "user", "content": prompt}])