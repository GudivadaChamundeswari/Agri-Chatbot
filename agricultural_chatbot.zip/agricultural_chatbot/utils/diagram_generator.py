from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt
import numpy as np
import io
import base64
from config import Config

class DiagramGenerator:
    @staticmethod
    def generate_growth_chart(crop_name, days, heights):
        plt.figure(figsize=(10, 6))
        plt.plot(days, heights, marker='o', linestyle='-', color='green')
        plt.title(f'{crop_name} Growth Chart')
        plt.xlabel('Days')
        plt.ylabel('Height (cm)')
        plt.grid(True)
        
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        plt.close()
        
        return base64.b64encode(buf.read()).decode('utf-8')
    
    @staticmethod
    def generate_soil_composition_chart(labels, sizes):
        colors = ['#ff9999','#66b3ff','#99ff99','#ffcc99']
        plt.figure(figsize=(8, 8))
        plt.pie(sizes, labels=labels, autopct='%1.1f%%', colors=colors, startangle=90)
        plt.title('Soil Composition')
        plt.axis('equal')
        
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        plt.close()
        
        return base64.b64encode(buf.read()).decode('utf-8')
    
    @staticmethod
    def generate_crop_rotation_diagram(crops, years):
        fig, ax = plt.subplots(figsize=(12, 6))
        
        colors = plt.cm.tab20.colors
        bar_height = 0.6
        
        for i, year in enumerate(years):
            for j, crop in enumerate(crops[i]):
                ax.barh(i, 1, height=bar_height, left=j, color=colors[j % len(colors)])
                ax.text(j + 0.5, i, crop, ha='center', va='center', color='white')
        
        ax.set_yticks(range(len(years)))
        ax.set_yticklabels(years)
        ax.set_xlabel('Seasons')
        ax.set_title('Recommended Crop Rotation Plan')
        ax.set_xlim(0, len(crops[0]))
        
        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        plt.close()
        
        return base64.b64encode(buf.read()).decode('utf-8')