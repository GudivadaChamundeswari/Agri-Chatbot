import requests
from config import Config
import geocoder

class WeatherAPI:
    BASE_URL = "https://api.openweathermap.org/data/2.5/weather"
    
    def __init__(self):
        self.api_key = Config.WEATHER_API_KEY
    
    def get_current_weather(self, location=None):
        if not location:
            # Try to get approximate location
            g = geocoder.ip('me')
            if g.ok:
                lat, lon = g.latlng
                location = f"{lat},{lon}"
            else:
                return "Unable to determine location"
        
        params = {
            'q': location if ',' not in location else None,
            'lat': location.split(',')[0] if ',' in location else None,
            'lon': location.split(',')[1] if ',' in location else None,
            'appid': self.api_key,
            'units': 'metric'
        }
        
        try:
            response = requests.get(self.BASE_URL, params=params)
            data = response.json()
            
            if response.status_code == 200:
                weather = {
                    'location': data['name'],
                    'temp': data['main']['temp'],
                    'humidity': data['main']['humidity'],
                    'conditions': data['weather'][0]['description'],
                    'wind_speed': data['wind']['speed'],
                    'rain': data.get('rain', {}).get('1h', 0),
                    'icon': data['weather'][0]['icon']
                }
                return weather
            else:
                return f"Weather API error: {data.get('message', 'Unknown error')}"
        except Exception as e:
            return f"Error fetching weather data: {str(e)}"
    
    def get_agricultural_advice(self, weather_data):
        if isinstance(weather_data, str):
            return weather_data  # Return the error message
        
        advice = []
        temp = weather_data['temp']
        humidity = weather_data['humidity']
        rain = weather_data['rain']
        wind_speed = weather_data['wind_speed']
        
        # Temperature advice
        if temp < 5:
            advice.append("Warning: Frost risk. Protect sensitive crops.")
        elif temp > 30:
            advice.append("High temperatures expected. Ensure adequate irrigation.")
        
        # Humidity advice
        if humidity > 80:
            advice.append("High humidity may promote fungal diseases. Consider preventive measures.")
        elif humidity < 30:
            advice.append("Low humidity. Monitor for drought stress in plants.")
        
        # Rain advice
        if rain > 10:
            advice.append("Heavy rain expected. Ensure proper drainage to prevent waterlogging.")
        elif rain == 0 and temp > 25:
            advice.append("No rain expected with high temperatures. Irrigation will be necessary.")
        
        # Wind advice
        if wind_speed > 15:
            advice.append("Strong winds expected. Secure greenhouses and protect tall crops.")
        
        return advice if advice else "Weather conditions are generally favorable for most crops."