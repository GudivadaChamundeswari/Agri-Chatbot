import os

class Config:
    GROQ_API_KEY = os.getenv('GROQ_API_KEY', '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')
    WEATHER_API_KEY = os.getenv('WEATHER_API_KEY', '7b5a5c2ca24c1beacbc35a00e100a4ba')
    SECRET_KEY = os.getenv('SECRET_KEY', 'secret-key-for-flask')
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'recordings')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp3', 'wav', 'txt', 'pdf'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload size