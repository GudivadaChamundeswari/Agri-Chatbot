 python 3.9.13

stp -1

 Run windows powershell as adminstrator in powershell enter follwoing comands one by one and enter

 # Run this in PowerShell as Administrator

# 1. Install Chocolatey (Windows package manager)
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
RefreshEnv

# 2. Install FFmpeg
choco install ffmpeg -y
$ffmpegPath = "$env:ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin"
[Environment]::SetEnvironmentVariable("Path", "$env:Path;$ffmpegPath", "Machine")


# 3. Install Tesseract OCR
choco install tesseract -y
$tesseractPath = "$env:ProgramFiles\Tesseract-OCR"
[Environment]::SetEnvironmentVariable("Path", "$env:Path;$tesseractPath", "Machine")
[Environment]::SetEnvironmentVariable("TESSDATA_PREFIX", "$tesseractPath\tessdata", "Machine")

# 4. Verify installations
Write-Host "`nVerifying installations..." -ForegroundColor Cyan
ffmpeg -version | Select-Object -First 1
tesseract --version


# 5. Refresh environment variables
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")

Write-Host "`nInstallation complete! Please restart your PowerShell/terminal for PATH changes to take effect." -ForegroundColor Green

[Environment]::SetEnvironmentVariable("Path", "$env:Path;C:\path\to\ffmpeg\bin;C:\Program Files\Tesseract-OCR", "Machine")



# Add Chocolatey bins to PATH (if not already present)
[Environment]::SetEnvironmentVariable(
    "Path",
    [Environment]::GetEnvironmentVariable("Path", "Machine") + ";C:\ProgramData\chocolatey\bin",
    "Machine"
)

# Refresh current session
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine")




for GROQ_API_KEY  visit
 https://console.groq.com/
  sign up with an account later click on create api key name it tap enter and copy the key and paste in ' '

for WEATHER_API_KEY visit
https://home.openweathermap.org/users/sign_up
 sign up with an image and name key and paste it in '  '