from flask import Flask, render_template, request, jsonify, session, send_from_directory
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from config import Config
from utils.groq_client import GroqClient
from utils.weather_api import WeatherAPI
from utils.diagram_generator import DiagramGenerator
from utils.audio_utils import AudioUtils
import base64
import json

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = app.config['SECRET_KEY']

groq_client = GroqClient()
weather_api = WeatherAPI()

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

@app.route('/')
def index():
    if 'conversation' not in session:
        session['conversation'] = []
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    user_input = request.form.get('message')
    file = request.files.get('file')
    voice_note = request.files.get('voice_note')
    location = request.form.get('location')
    
    messages = []
    
    # Add previous conversation to context
    for msg in session.get('conversation', []):
        messages.append({"role": msg['role'], "content": msg['content']})
    
    # Process voice note
    if voice_note:
        filename = secure_filename(f"voice_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav")
        voice_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        voice_note.save(voice_path)
        
        transcribed_text = AudioUtils.speech_to_text(voice_path)
        if transcribed_text:
            user_input = f"{user_input}\n[Voice note transcription]: {transcribed_text}" if user_input else transcribed_text
            session['conversation'].append({"role": "user", "content": f"[Voice note]: {transcribed_text}", "type": "audio"})
    
    # Process file upload
    file_content = None
    if file and allowed_file(file.filename):
        filename = secure_filename(f"file_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        if file.filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
            # Image analysis
            file_content = groq_client.generate_image_description(file_path)
            session['conversation'].append({"role": "user", "content": f"[Image uploaded]: {file.filename}", "type": "image"})
        elif file.filename.lower().endswith(('.txt', '.pdf')):
            # Text document analysis
            with open(file_path, 'r') as f:
                text = f.read()
            file_content = groq_client.analyze_document(text)
            session['conversation'].append({"role": "user", "content": f"[Document uploaded]: {file.filename}", "type": "document"})
    
    # Add user message to conversation
    if user_input:
        session['conversation'].append({"role": "user", "content": user_input, "type": "text"})
    
    # Get weather data if location is provided
    weather_data = None
    weather_advice = None
    if location:
        weather_data = weather_api.get_current_weather(location)
        if isinstance(weather_data, dict):
            weather_advice = weather_api.get_agricultural_advice(weather_data)
            session['conversation'].append({
                "role": "system", 
                "content": f"Weather data for {location}: {weather_data}. Advice: {weather_advice}",
                "type": "weather"
            })
    
    # Prepare messages for Groq API
    messages.append({"role": "user", "content": user_input})
    if file_content:
        messages.append({"role": "user", "content": f"File analysis: {file_content}"})
    if weather_advice:
        messages.append({"role": "user", "content": f"Weather advice needed: {weather_advice}"})
    
    # Get response from Groq
    response = groq_client.get_response(messages)
    
    # Check if response contains diagram request
    diagram_data = None
    if "[DIAGRAM:" in response:
        try:
            diagram_type = response.split("[DIAGRAM:")[1].split("]")[0]
            response = response.replace(f"[DIAGRAM:{diagram_type}]", "")
            
            if diagram_type == "GROWTH_CHART":
                # Example data - in real app, this would come from user input or database
                diagram_data = DiagramGenerator.generate_growth_chart(
                    "Tomato", 
                    [0, 7, 14, 21, 28, 35], 
                    [0, 5, 12, 25, 45, 70]
                )
            elif diagram_type == "SOIL_COMPOSITION":
                diagram_data = DiagramGenerator.generate_soil_composition_chart(
                    ['Sand', 'Clay', 'Silt', 'Organic Matter'],
                    [40, 30, 20, 10]
                )
            elif diagram_type == "CROP_ROTATION":
                diagram_data = DiagramGenerator.generate_crop_rotation_diagram(
                    [['Corn', 'Beans', 'Wheat', 'Fallow'],
                     ['Beans', 'Wheat', 'Fallow', 'Corn'],
                     ['Wheat', 'Fallow', 'Corn', 'Beans']],
                    ['Year 1', 'Year 2', 'Year 3']
                )
        except Exception as e:
            print(f"Error generating diagram: {e}")
    
    # Generate voice response
    voice_filename = AudioUtils.text_to_speech(response)
    voice_url = f"/recordings/{voice_filename}" if voice_filename else None
    
    # Add assistant response to conversation
    session['conversation'].append({
        "role": "assistant", 
        "content": response,
        "type": "text",
        "voice_url": voice_url,
        "diagram": diagram_data
    })
    
    # Save conversation to session
    session.modified = True
    
    return jsonify({
        "response": response,
        "voice_url": voice_url,
        "diagram": diagram_data,
        "weather": weather_data if isinstance(weather_data, dict) else None,
        "weather_advice": weather_advice if weather_advice else None
    })

@app.route('/recordings/<filename>')
def serve_recording(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/api/conversation')
def get_conversation():
    return jsonify(session.get('conversation', []))

@app.route('/api/clear', methods=['POST'])
def clear_conversation():
    session['conversation'] = []
    session.modified = True
    return jsonify({"status": "success"})

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

if __name__ == '__main__':
    app.run(debug=True)